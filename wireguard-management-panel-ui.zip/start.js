// Production start script for Railway (and any Node host).
// Next.js already reads the PORT env var, but we pass it explicitly so the
// server always binds to the port Railway assigns.
const { spawn } = require("child_process");

const port = process.env.PORT || "3000";
const host = process.env.HOST || "0.0.0.0";

console.log(`[PUG62] Starting Next.js production server on ${host}:${port}`);

const child = spawn(
  process.platform === "win32" ? "npx.cmd" : "npx",
  ["next", "start", "-H", host, "-p", port],
  { stdio: "inherit", env: process.env }
);

child.on("exit", (code) => process.exit(code ?? 0));
