# PUG62 WireGuard Management Panel

پنل مدیریت وایرگارد PUG62 — ساخته‌شده با Next.js + PostgreSQL، آماده‌ی دیپلوی روی Railway.

## امکانات

- ورود با **نام کاربری + رمز عبور** (نه فقط رمز)
- حساب مدیر (Admin): پیش‌فرض `arian` / `arian@11USER`
- بخش **USERS** فقط برای مدیر: ساخت کاربر عادی با نام کاربری، رمز و تعداد روز اعتبار (مثلاً ۱۰ روز)
- مدیر می‌تواند: تعداد کاربران و کانفیگ‌هایشان را ببیند، روز اضافه کند (تمدید)، فعال/غیرفعال کند، رمز را عوض کند و کاربر را حذف کند
- کاربر عادی هنگام ورود می‌بیند چند روز از اعتبار حسابش مانده
- ساخت/مدیریت کانفیگ وایرگارد (UAE / TR / IR)، دانلود `.conf`، آمار مصرف
- **لینک ساب (Subscription):** `https://YOUR-DOMAIN/api/sub/<subId>` که محتوای کانفیگ را برمی‌گرداند و در کلاینت‌های وایرگارد قابل استفاده است
- دو زبانه (EN / FA) با پشتیبانی راست‌به‌چپ

## دیپلوی روی Railway

1. این پروژه را روی گیت‌هاب بگذارید.
2. در Railway یک پروژه‌ی جدید بسازید → **Deploy from GitHub repo**.
3. سرویس **PostgreSQL** را از داخل Railway اضافه کنید (Add → Database → PostgreSQL).
4. در تنظیمات سرویس برنامه، متغیر محیطی زیر را اضافه کنید:
   - `DATABASE_URL` → مقدار `${{ Postgres.DATABASE_URL }}` (رفرنس به دیتابیس Railway)
   - (اختیاری) `SESSION_SECRET` → یک رشته‌ی تصادفی امن
   - (اختیاری) `ADMIN_USERNAME` و `ADMIN_PASSWORD` برای تغییر حساب مدیر
5. Railway به‌صورت خودکار `npm run build` و سپس `node start.js` را اجرا می‌کند.
6. جدول‌های دیتابیس و حساب مدیر در اولین اجرا **به‌صورت خودکار** ساخته می‌شوند (نیازی به migration دستی نیست).

### Healthcheck
مسیر سلامت: `/api/health`

## اجرای محلی

```bash
npm install
# .env : DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/app_db
npm run build
node start.js   # یا: npm run start
```

ورود مدیر پیش‌فرض: `arian` / `arian@11USER`
