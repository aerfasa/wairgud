"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { makeT, type Lang } from "@/lib/i18n";
import { WG_SERVERS } from "@/lib/wireguard";
import type {
  ClientConfig,
  SessionUser,
  AdminUser,
  UsageEntry,
} from "@/lib/types";

type ToastType = "success" | "danger" | "warning" | "info";

export default function Page() {
  const [lang, setLang] = useState<Lang>("en");
  const [booted, setBooted] = useState(false);
  const [user, setUser] = useState<SessionUser | null>(null);
  const [configs, setConfigs] = useState<ClientConfig[]>([]);

  // toast
  const [toast, setToast] = useState<{
    show: boolean;
    title: string;
    message: string;
    type: ToastType;
  }>({ show: false, title: "", message: "", type: "success" });
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const t = makeT(lang);

  const showToast = useCallback(
    (title: string, message: string, type: ToastType = "success") => {
      setToast({ show: true, title, message, type });
      if (toastTimer.current) clearTimeout(toastTimer.current);
      toastTimer.current = setTimeout(
        () => setToast((p) => ({ ...p, show: false })),
        5000
      );
    },
    []
  );

  const applyLang = useCallback((l: Lang) => {
    setLang(l);
    if (typeof window !== "undefined") {
      localStorage.setItem("pug62_lang", l);
      document.body.classList.toggle("rtl", l === "fa");
      document.documentElement.setAttribute("lang", l);
    }
  }, []);

  const loadConfigs = useCallback(async () => {
    const res = await fetch("/api/configs");
    if (res.ok) {
      const data = await res.json();
      setConfigs(data.configs || []);
    }
  }, []);

  // boot
  useEffect(() => {
    const savedLang = (localStorage.getItem("pug62_lang") as Lang) || "en";
    applyLang(savedLang);
    (async () => {
      const res = await fetch("/api/auth/me");
      if (res.ok) {
        const data = await res.json();
        setUser(data.user);
        await loadConfigs();
      }
      setBooted(true);
    })();
  }, [applyLang, loadConfigs]);

  const handleLoggedIn = useCallback(
    async (u: SessionUser) => {
      setUser(u);
      await loadConfigs();
      showToast(t("toastLoginGrantedTitle"), t("toastLoginGrantedMsg"), "success");
    },
    [loadConfigs, showToast, t]
  );

  const handleLogout = useCallback(async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    setUser(null);
    setConfigs([]);
  }, []);

  if (!booted) {
    return (
      <>
        <LangToggle lang={lang} setLang={applyLang} />
        <div className="login-screen">
          <div className="login-container">
            <div className="logo">PUG62</div>
            <p className="tagline">Loading...</p>
          </div>
        </div>
      </>
    );
  }

  return (
    <>
      <LangToggle lang={lang} setLang={applyLang} />
      {!user ? (
        <Login t={t} onLoggedIn={handleLoggedIn} showToast={showToast} />
      ) : (
        <Panel
          t={t}
          user={user}
          configs={configs}
          reloadConfigs={loadConfigs}
          onLogout={handleLogout}
          showToast={showToast}
          setUser={setUser}
        />
      )}
      <Toast toast={toast} />
    </>
  );
}

/* ---------------- Language toggle ---------------- */
function LangToggle({
  lang,
  setLang,
}: {
  lang: Lang;
  setLang: (l: Lang) => void;
}) {
  return (
    <div className="lang-toggle">
      <button
        type="button"
        className={lang === "en" ? "active" : ""}
        onClick={() => setLang("en")}
      >
        EN
      </button>
      <button
        type="button"
        className={lang === "fa" ? "active" : ""}
        onClick={() => setLang("fa")}
      >
        FA
      </button>
    </div>
  );
}

/* ---------------- Toast ---------------- */
function Toast({
  toast,
}: {
  toast: { show: boolean; title: string; message: string; type: ToastType };
}) {
  const border =
    toast.type === "danger"
      ? "var(--danger)"
      : toast.type === "warning"
      ? "var(--warning)"
      : "var(--primary)";
  const icon =
    toast.type === "danger"
      ? "fa-exclamation-circle"
      : toast.type === "warning"
      ? "fa-exclamation-triangle"
      : toast.type === "info"
      ? "fa-info-circle"
      : "fa-check-circle";
  return (
    <div className={`toast ${toast.show ? "show" : ""}`} style={{ borderColor: border }}>
      <div className="toast-icon" style={{ color: border }}>
        <i className={`fas ${icon}`} />
      </div>
      <div className="toast-content">
        <h4>{toast.title}</h4>
        <p>{toast.message}</p>
      </div>
    </div>
  );
}

/* ---------------- Login ---------------- */
function Login({
  t,
  onLoggedIn,
  showToast,
}: {
  t: (k: string) => string;
  onLoggedIn: (u: SessionUser) => void;
  showToast: (title: string, message: string, type?: ToastType) => void;
}) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [shake, setShake] = useState(false);
  const [loading, setLoading] = useState(false);

  const submit = async () => {
    if (loading) return;
    setLoading(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });
      const data = await res.json().catch(() => ({}));
      if (res.ok && data.ok) {
        onLoggedIn(data.user);
        return;
      }
      const err = data.error;
      let msg = t("toastInvalidCreds");
      if (err === "ACCOUNT_EXPIRED") msg = t("toastExpired");
      else if (err === "ACCOUNT_DISABLED") msg = t("toastDisabled");
      showToast(t("toastLoginDeniedTitle"), msg, "danger");
      setShake(true);
      setTimeout(() => setShake(false), 500);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-screen">
      <div className={`login-container ${shake ? "shake" : ""}`}>
        <div className="logo">PUG62</div>
        <p className="tagline">{t("loginTagline")}</p>

        <div className="input-group">
          <label>
            <i className="fas fa-user" /> {t("loginUserLabel")}
          </label>
          <input
            type="text"
            value={username}
            placeholder={t("loginUserPlaceholder")}
            onChange={(e) => setUsername(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && submit()}
          />
        </div>

        <div className="input-group">
          <label>
            <i className="fas fa-key" /> {t("loginPasswordLabel")}
          </label>
          <input
            type="password"
            value={password}
            placeholder={t("loginPasswordPlaceholder")}
            onChange={(e) => setPassword(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && submit()}
          />
        </div>

        <button className="login-btn" onClick={submit} disabled={loading}>
          <i className="fas fa-sign-in-alt" /> {t("loginBtn")}
        </button>

        <div className="login-footer">
          <p>{t("loginHint")}</p>
          <p>
            {t("loginFooter2By")}{" "}
            <a href="https://t.me/PUG62" target="_blank" rel="noreferrer">
              PUG62 TELEGRAM CHANNEL
            </a>
          </p>
        </div>
      </div>
    </div>
  );
}

/* ---------------- Panel ---------------- */
type ModalKind =
  | null
  | "create"
  | "details"
  | "usage"
  | "addData"
  | "addDays"
  | "sub"
  | "users";

function Panel({
  t,
  user,
  configs,
  reloadConfigs,
  onLogout,
  showToast,
  setUser,
}: {
  t: (k: string) => string;
  user: SessionUser;
  configs: ClientConfig[];
  reloadConfigs: () => Promise<void>;
  onLogout: () => void;
  showToast: (title: string, message: string, type?: ToastType) => void;
  setUser: (u: SessionUser) => void;
}) {
  const [modal, setModal] = useState<ModalKind>(null);
  const [activeConfig, setActiveConfig] = useState<ClientConfig | null>(null);
  const [openMenuId, setOpenMenuId] = useState<number | null>(null);
  const [subLink, setSubLink] = useState("");

  useEffect(() => {
    const close = () => setOpenMenuId(null);
    document.addEventListener("click", close);
    return () => document.removeEventListener("click", close);
  }, []);

  const patchConfig = async (id: number, body: Record<string, unknown>) => {
    const res = await fetch(`/api/configs/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    return res.json().catch(() => ({}));
  };

  const toggleStatus = async (c: ClientConfig) => {
    await patchConfig(c.id, { action: "toggle" });
    await reloadConfigs();
  };

  const downloadConfig = (c: ClientConfig) => {
    const blob = new Blob([c.configText], { type: "application/octet-stream" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = c.name.endsWith(".conf") ? c.name : `${c.name}.conf`;
    link.click();
    URL.revokeObjectURL(link.href);
    showToast(
      t("toastConfigDownloadedTitle"),
      t("toastConfigDownloadedMsg").replace("{name}", c.name),
      "success"
    );
  };

  const getSubLink = (c: ClientConfig) =>
    `${window.location.origin}/api/sub/${c.subId}`;

  const copySubLink = async (c: ClientConfig) => {
    const link = getSubLink(c);
    setSubLink(link);
    try {
      await navigator.clipboard.writeText(link);
      showToast(t("toastLinkCopiedTitle"), t("toastLinkCopiedMsg"), "success");
    } catch {
      setActiveConfig(c);
      setModal("sub");
    }
  };

  const deleteConfig = async (c: ClientConfig) => {
    if (!window.confirm(t("confirmDeleteConfig"))) return;
    await fetch(`/api/configs/${c.id}`, { method: "DELETE" });
    await reloadConfigs();
    showToast(
      t("toastConfigDeletedTitle"),
      t("toastConfigDeletedMsg").replace("{name}", c.name),
      "success"
    );
  };

  const recordUsage = async (c: ClientConfig) => {
    const data = await patchConfig(c.id, { action: "recordUsage" });
    if (data.ok) {
      await reloadConfigs();
      if (data.config) setActiveConfig(data.config);
      if (data.limitExceeded) {
        showToast(t("toastLimitTitle"), t("toastLimitMsg"), "warning");
      } else {
        showToast(t("toastUsageRecordedTitle"), t("toastUsageRecordedMsg"), "success");
      }
    } else {
      showToast(t("toastErrorTitle"), t("toastErrorTitle"), "danger");
    }
  };

  return (
    <div className="main-panel">
      <header className="header">
        <div className="header-left">
          <h1>
            <i className="fas fa-shield-alt" /> PUG62 WIREGUARD PANEL
          </h1>
          <p>{t("headerTagline")}</p>
        </div>
        <div className="header-right">
          <button className="btn btn-primary" onClick={() => setModal("create")}>
            <i className="fas fa-plus" /> {t("createConfigBtn")}
          </button>
          {user.role === "admin" && (
            <button className="btn" onClick={() => setModal("users")}>
              <i className="fas fa-users-cog" /> {t("usersBtn")}
            </button>
          )}
          <div className="user-info">
            <i className="fas fa-user-secret" />
            <span>
              {user.username}
              {user.role === "admin" ? ` · ${t("adminLabel")}` : ""}
            </span>
          </div>
          <button className="btn btn-danger" onClick={onLogout}>
            <i className="fas fa-sign-out-alt" /> {t("logoutBtn")}
          </button>
        </div>
      </header>

      {/* account validity banner */}
      <div className="account-banner">
        <div>
          <i className="fas fa-clock" style={{ color: "var(--primary)", marginInlineEnd: 8 }} />
          {user.role === "admin" ? (
            <span>{t("accountUnlimited")}</span>
          ) : (
            <span>
              <span className="days-badge">{user.daysLeft}</span> {t("accountDaysLeft")}
            </span>
          )}
        </div>
        {user.role !== "admin" && user.expiresAt && (
          <span style={{ color: "var(--gray)" }}>
            {new Date(user.expiresAt).toLocaleDateString("en-US")}
          </span>
        )}
      </div>

      <div className="dashboard">
        {configs.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">
              <i className="fas fa-shield-alt" />
            </div>
            <h3>{t("emptyStateTitle")}</h3>
            <p>{t("emptyStateDesc")}</p>
            <button className="btn btn-primary" onClick={() => setModal("create")}>
              <i className="fas fa-plus" /> {t("emptyStateBtn")}
            </button>
          </div>
        ) : (
          configs.map((c) => (
            <ConfigCard
              key={c.id}
              c={c}
              t={t}
              openMenu={openMenuId === c.id}
              onMenuToggle={(e) => {
                e.stopPropagation();
                setOpenMenuId(openMenuId === c.id ? null : c.id);
              }}
              onToggle={() => toggleStatus(c)}
              onDetails={() => {
                setActiveConfig(c);
                setModal("details");
              }}
              onUsage={() => {
                setActiveConfig(c);
                setModal("usage");
              }}
              onDownload={() => downloadConfig(c)}
              onSub={() => copySubLink(c)}
              onAddData={() => {
                setActiveConfig(c);
                setModal("addData");
              }}
              onAddDays={() => {
                setActiveConfig(c);
                setModal("addDays");
              }}
              onDelete={() => deleteConfig(c)}
            />
          ))
        )}
      </div>

      <footer className="footer">
        <p>{t("footerCopyright")}</p>
        <a href="https://t.me/PUG62" target="_blank" rel="noreferrer" className="telegram-link">
          <i className="fab fa-telegram" /> {t("footerTelegram")}
        </a>
      </footer>

      {modal === "create" && (
        <CreateConfigModal
          t={t}
          onClose={() => setModal(null)}
          onCreated={async (c) => {
            await reloadConfigs();
            setModal(null);
            showToast(
              t("toastConfigCreatedTitle"),
              t("toastConfigCreatedMsg").replace("{name}", c.name),
              "success"
            );
            downloadConfig(c);
          }}
          showToast={showToast}
        />
      )}

      {modal === "details" && activeConfig && (
        <DetailsModal
          t={t}
          c={activeConfig}
          onClose={() => setModal(null)}
          onDownload={() => {
            downloadConfig(activeConfig);
            setModal(null);
          }}
        />
      )}

      {modal === "usage" && activeConfig && (
        <UsageModal
          t={t}
          c={activeConfig}
          onClose={() => setModal(null)}
          onRecord={() => recordUsage(activeConfig)}
        />
      )}

      {modal === "addData" && activeConfig && (
        <AmountModal
          title={t("addDataTitle")}
          label={t("amountToAddLabel")}
          desc={t("addDataDesc")}
          icon="fa-database"
          confirmLabel={t("addDataBtn")}
          cancelLabel={t("cancelBtn")}
          initial={10}
          onClose={() => setModal(null)}
          onConfirm={async (amount) => {
            await patchConfig(activeConfig.id, { action: "addData", amount });
            await reloadConfigs();
            setModal(null);
            showToast(
              t("toastDataAddedTitle"),
              t("toastDataAddedMsg")
                .replace("{amount}", String(amount))
                .replace("{name}", activeConfig.name),
              "success"
            );
          }}
        />
      )}

      {modal === "addDays" && activeConfig && (
        <AmountModal
          title={t("extendValidityTitle")}
          label={t("daysToAddLabel")}
          desc={t("addDaysDesc")}
          icon="fa-calendar-plus"
          confirmLabel={t("addDaysBtn")}
          cancelLabel={t("cancelBtn")}
          initial={30}
          onClose={() => setModal(null)}
          onConfirm={async (days) => {
            await patchConfig(activeConfig.id, { action: "addDays", days });
            await reloadConfigs();
            setModal(null);
            showToast(
              t("toastValidityTitle"),
              t("toastValidityMsg")
                .replace("{days}", String(days))
                .replace("{name}", activeConfig.name),
              "success"
            );
          }}
        />
      )}

      {modal === "sub" && (
        <SubLinkModal t={t} link={subLink} onClose={() => setModal(null)} />
      )}

      {modal === "users" && user.role === "admin" && (
        <UsersModal
          t={t}
          onClose={() => setModal(null)}
          showToast={showToast}
          refreshMe={async () => {
            const res = await fetch("/api/auth/me");
            if (res.ok) {
              const d = await res.json();
              setUser(d.user);
            }
          }}
        />
      )}
    </div>
  );
}

/* ---------------- Config Card ---------------- */
function ConfigCard({
  c,
  t,
  openMenu,
  onMenuToggle,
  onToggle,
  onDetails,
  onUsage,
  onDownload,
  onSub,
  onAddData,
  onAddDays,
  onDelete,
}: {
  c: ClientConfig;
  t: (k: string) => string;
  openMenu: boolean;
  onMenuToggle: (e: React.MouseEvent) => void;
  onToggle: () => void;
  onDetails: () => void;
  onUsage: () => void;
  onDownload: () => void;
  onSub: () => void;
  onAddData: () => void;
  onAddDays: () => void;
  onDelete: () => void;
}) {
  const server = WG_SERVERS[c.country];
  const volumePercent =
    c.volume === -1 ? 0 : Math.min(100, (c.volumeUsed / c.volume) * 100);
  const dailyPercent =
    c.dailyLimit === -1 ? 0 : Math.min(100, (c.dailyUsed / c.dailyLimit) * 100);
  const daysRemaining = Math.max(
    0,
    Math.ceil((new Date(c.expiresAt).getTime() - Date.now()) / 86400000)
  );

  const menuItem = (
    icon: string,
    label: string,
    onClick: () => void,
    danger = false
  ) => (
    <div
      className="dropdown-item"
      style={danger ? { color: "var(--danger)" } : undefined}
      onClick={(e) => {
        e.stopPropagation();
        onClick();
      }}
    >
      <i className={`fas ${icon}`} />
      <span>{label}</span>
    </div>
  );

  return (
    <div className="config-card">
      <div className="config-header">
        <h3 className="config-title">{c.name}</h3>
        <div className="config-menu">
          <button className="menu-btn" onClick={onMenuToggle}>
            <i className="fas fa-ellipsis-v" />
          </button>
          {openMenu && (
            <div className="dropdown-menu">
              {menuItem(
                "fa-power-off",
                c.isActive ? t("menuDeactivate") : t("menuActivate"),
                onToggle
              )}
              {menuItem("fa-info-circle", t("menuViewDetails"), onDetails)}
              {menuItem("fa-chart-bar", t("menuUsageStats"), onUsage)}
              {menuItem("fa-database", t("menuAddData"), onAddData)}
              {menuItem("fa-calendar-plus", t("menuAddDays"), onAddDays)}
              {menuItem("fa-download", t("menuDownloadConfig"), onDownload)}
              {menuItem("fa-link", t("menuCopySubLink"), onSub)}
              {menuItem("fa-trash", t("menuDeleteConfig"), onDelete, true)}
            </div>
          )}
        </div>
      </div>

      <div className="config-status">
        <div className={`status-indicator ${c.isActive ? "" : "off"}`} />
        <span className="status-text">
          {c.isActive ? t("statusActive") : t("statusInactive")}
        </span>
        <label className="toggle-switch" style={{ marginInlineStart: "auto" }}>
          <input type="checkbox" checked={c.isActive} onChange={onToggle} />
          <span className="slider" />
        </label>
      </div>

      <div className="config-details">
        <div className="detail-item">
          <div className="detail-label">{t("labelServer")}</div>
          <div className="detail-value">{server.country}</div>
        </div>
        <div className="detail-item">
          <div className="detail-label">{t("labelDaysLeft")}</div>
          <div className="detail-value">{daysRemaining}</div>
        </div>
        <div className="detail-item">
          <div className="detail-label">{t("labelTotalData")}</div>
          <div className="detail-value">
            {c.volume === -1 ? t("unlimitedOption") : `${c.volume} GB`}
          </div>
        </div>
        <div className="detail-item">
          <div className="detail-label">{t("labelUsedData")}</div>
          <div className="detail-value">{c.volumeUsed.toFixed(1)} GB</div>
        </div>
      </div>

      <div className="progress-container">
        <div className="progress-header">
          <span className="progress-label">{t("labelDataUsage")}</span>
          <span className="progress-value">
            {c.volumeUsed.toFixed(1)} / {c.volume === -1 ? "∞" : c.volume} GB
          </span>
        </div>
        <div className="progress-bar">
          <div className="progress-fill" style={{ width: `${volumePercent}%` }} />
        </div>
      </div>

      <div className="progress-container">
        <div className="progress-header">
          <span className="progress-label">{t("labelDailyUsage")}</span>
          <span className="progress-value">
            {c.dailyUsed.toFixed(1)} / {c.dailyLimit === -1 ? "∞" : c.dailyLimit} GB
          </span>
        </div>
        <div className="progress-bar">
          <div
            className="progress-fill"
            style={{
              width: `${dailyPercent}%`,
              background:
                dailyPercent > 80
                  ? "linear-gradient(90deg, var(--warning), var(--danger))"
                  : "linear-gradient(90deg, var(--primary), var(--success))",
            }}
          />
        </div>
      </div>

      <div className="config-actions">
        <button className="btn" onClick={onDetails}>
          <i className="fas fa-info-circle" /> {t("btnDetails")}
        </button>
        <button className="btn" onClick={onDownload}>
          <i className="fas fa-download" /> {t("btnDownload")}
        </button>
        <button className="btn" onClick={onUsage}>
          <i className="fas fa-chart-line" /> {t("btnUsage")}
        </button>
        <button className="btn" onClick={onSub}>
          <i className="fas fa-link" /> {t("btnSub")}
        </button>
      </div>
    </div>
  );
}

/* ---------------- Modal shell ---------------- */
function ModalShell({
  title,
  icon,
  onClose,
  children,
  footer,
  wide,
}: {
  title: string;
  icon: string;
  onClose: () => void;
  children: React.ReactNode;
  footer: React.ReactNode;
  wide?: boolean;
}) {
  return (
    <div className="modal" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className={`modal-content ${wide ? "wide" : ""}`}>
        <div className="modal-header">
          <h2 className="modal-title">
            <i className={`fas ${icon}`} /> {title}
          </h2>
          <button className="close-modal" onClick={onClose}>
            &times;
          </button>
        </div>
        <div className="modal-body">{children}</div>
        <div className="modal-footer">{footer}</div>
      </div>
    </div>
  );
}

/* ---------------- Create Config Modal ---------------- */
function CreateConfigModal({
  t,
  onClose,
  onCreated,
  showToast,
}: {
  t: (k: string) => string;
  onClose: () => void;
  onCreated: (c: ClientConfig) => void;
  showToast: (title: string, message: string, type?: ToastType) => void;
}) {
  const [name, setName] = useState("");
  const [country, setCountry] = useState("UAE");
  const [volume, setVolume] = useState("100");
  const [days, setDays] = useState("30");
  const [dailyLimit, setDailyLimit] = useState("10");
  const [loading, setLoading] = useState(false);

  const submit = async () => {
    if (!name.trim()) {
      showToast(t("toastErrorTitle"), t("toastNeedName"), "danger");
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("/api/configs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: name.trim(), country, volume, days: Number(days), dailyLimit }),
      });
      const data = await res.json().catch(() => ({}));
      if (data.ok) onCreated(data.config);
      else showToast(t("toastErrorTitle"), t("toastErrorTitle"), "danger");
    } finally {
      setLoading(false);
    }
  };

  return (
    <ModalShell
      title={t("createModalTitle")}
      icon="fa-plus-circle"
      onClose={onClose}
      footer={
        <>
          <button className="btn" onClick={onClose}>
            {t("cancelBtn")}
          </button>
          <button className="btn btn-primary" onClick={submit} disabled={loading}>
            {t("createConfigBtn")}
          </button>
        </>
      }
    >
      <div className="form-group">
        <label>{t("configNameLabel")}</label>
        <div className="fancy-input">
          <i className="fas fa-user-tag" />
          <input
            type="text"
            value={name}
            placeholder={t("configNamePlaceholder")}
            onChange={(e) => setName(e.target.value)}
          />
        </div>
      </div>

      <div className="form-row">
        <div className="form-group">
          <label>{t("serverLocationLabel")}</label>
          <select value={country} onChange={(e) => setCountry(e.target.value)}>
            <option value="UAE">🇦🇪 UAE (Dubai)</option>
            <option value="TR">🇹🇷 Turkey (Istanbul)</option>
            <option value="IR">🇮🇷 Iran (Tehran)</option>
          </select>
        </div>
        <div className="form-group">
          <label>{t("dataVolumeLabel")}</label>
          <select value={volume} onChange={(e) => setVolume(e.target.value)}>
            <option value="50">50 GB</option>
            <option value="100">100 GB</option>
            <option value="200">200 GB</option>
            <option value="500">500 GB</option>
            <option value="unlimited">{t("unlimitedOption")}</option>
          </select>
        </div>
      </div>

      <div className="form-row">
        <div className="form-group">
          <label>{t("validityPeriodLabel")}</label>
          <select value={days} onChange={(e) => setDays(e.target.value)}>
            <option value="7">{t("days7")}</option>
            <option value="30">{t("days30")}</option>
            <option value="90">{t("days90")}</option>
            <option value="180">{t("days180")}</option>
            <option value="365">{t("days365")}</option>
          </select>
        </div>
        <div className="form-group">
          <label>{t("dailyLimitLabel")}</label>
          <select value={dailyLimit} onChange={(e) => setDailyLimit(e.target.value)}>
            <option value="5">5 GB/Day</option>
            <option value="10">10 GB/Day</option>
            <option value="20">20 GB/Day</option>
            <option value="50">50 GB/Day</option>
            <option value="unlimited">{t("unlimitedOption")}</option>
          </select>
        </div>
      </div>
    </ModalShell>
  );
}

/* ---------------- Details Modal ---------------- */
function DetailsModal({
  t,
  c,
  onClose,
  onDownload,
}: {
  t: (k: string) => string;
  c: ClientConfig;
  onClose: () => void;
  onDownload: () => void;
}) {
  const server = WG_SERVERS[c.country];
  const fmt = (d: string) =>
    new Date(d).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  const daysRemaining = Math.max(
    0,
    Math.ceil((new Date(c.expiresAt).getTime() - Date.now()) / 86400000)
  );
  const volumePercent =
    c.volume === -1 ? 0 : Math.min(100, (c.volumeUsed / c.volume) * 100);
  const dailyPercent =
    c.dailyLimit === -1 ? 0 : Math.min(100, (c.dailyUsed / c.dailyLimit) * 100);

  const item = (label: string, value: React.ReactNode) => (
    <div className="detail-item">
      <div className="detail-label">{label}</div>
      <div className="detail-value">{value}</div>
    </div>
  );

  return (
    <ModalShell
      title={t("configDetailsTitle")}
      icon="fa-info-circle"
      onClose={onClose}
      footer={
        <>
          <button className="btn" onClick={onClose}>
            {t("closeBtn")}
          </button>
          <button className="btn btn-primary" onClick={onDownload}>
            {t("downloadConfigBtn")}
          </button>
        </>
      }
    >
      <div className="config-details" style={{ gridTemplateColumns: "1fr" }}>
        {item(t("detailConfigName"), c.name)}
      </div>
      <div className="form-row">
        {item(t("detailServerLocation"), `${server.country} - ${server.city}`)}
        {item(t("detailServerIp"), `${server.ip}:${server.port}`)}
      </div>
      <div className="form-row">
        {item(t("detailCreatedDate"), fmt(c.createdAt))}
        {item(t("detailExpireDate"), `${fmt(c.expiresAt)} (${daysRemaining} ${t("detailDaysLeft")})`)}
      </div>
      <div className="form-row">
        {item(t("detailTotalData"), c.volume === -1 ? t("detailUnlimited") : `${c.volume} GB`)}
        {item(
          t("detailDataUsed"),
          `${c.volumeUsed.toFixed(1)} GB (${volumePercent.toFixed(1)}%)`
        )}
      </div>
      <div className="form-row">
        {item(
          t("detailDailyLimit"),
          c.dailyLimit === -1 ? t("detailUnlimited") : `${c.dailyLimit} GB`
        )}
        {item(
          t("detailDailyUsed"),
          `${c.dailyUsed.toFixed(1)} GB (${dailyPercent.toFixed(1)}%)`
        )}
      </div>
      <div className="detail-item">
        <div className="detail-label">{t("detailPublicKey")}</div>
        <div className="detail-value" style={{ fontSize: "0.8rem", wordBreak: "break-all" }}>
          {c.publicKey}
        </div>
      </div>
      <div className="detail-item">
        <div className="detail-label">{t("detailConfigStatus")}</div>
        <div className="detail-value">
          <span style={{ color: c.isActive ? "var(--success)" : "var(--danger)" }}>
            <i className={`fas fa-${c.isActive ? "check-circle" : "times-circle"}`} />{" "}
            {c.isActive ? t("statusActive").toUpperCase() : t("statusInactive").toUpperCase()}
          </span>
        </div>
      </div>
      <div className="progress-container" style={{ marginTop: 20 }}>
        <div className="progress-header">
          <span className="progress-label">{t("detailOverallUsage")}</span>
          <span className="progress-value">
            {c.volumeUsed.toFixed(1)} / {c.volume === -1 ? "∞" : c.volume} GB
          </span>
        </div>
        <div className="progress-bar">
          <div className="progress-fill" style={{ width: `${volumePercent}%` }} />
        </div>
      </div>
    </ModalShell>
  );
}

/* ---------------- Usage Modal ---------------- */
function UsageModal({
  t,
  c,
  onClose,
  onRecord,
}: {
  t: (k: string) => string;
  c: ClientConfig;
  onClose: () => void;
  onRecord: () => void;
}) {
  const daysUsed = c.daysUsed;
  const avgDaily = daysUsed > 0 ? c.volumeUsed / daysUsed : 0;
  const history: UsageEntry[] = c.usageHistory || [];
  const volumePercent =
    c.volume === -1 ? 0 : Math.min(100, (c.volumeUsed / c.volume) * 100);

  return (
    <ModalShell
      title={t("usageStatsTitle")}
      icon="fa-chart-line"
      onClose={onClose}
      footer={
        <button className="btn" onClick={onClose}>
          {t("closeBtn")}
        </button>
      }
    >
      <h3 style={{ marginBottom: 20, color: "var(--primary)" }}>
        {c.name} - {t("usageStatsTitle")}
      </h3>
      <div className="usage-stats">
        <div className="stat-card">
          <div className="stat-value">{c.volumeUsed.toFixed(1)}</div>
          <div className="stat-label">{t("usageGbUsed")}</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{avgDaily.toFixed(1)}</div>
          <div className="stat-label">{t("usageAvgDaily")}</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{daysUsed}</div>
          <div className="stat-label">{t("usageDaysUsed")}</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{c.dailyUsed.toFixed(1)}</div>
          <div className="stat-label">{t("usageGbToday")}</div>
        </div>
      </div>

      <div className="progress-container" style={{ margin: "20px 0" }}>
        <div className="progress-header">
          <span className="progress-label">{t("usageTotalDataUsage")}</span>
          <span className="progress-value">
            {c.volumeUsed.toFixed(1)} / {c.volume === -1 ? "∞" : c.volume} GB
          </span>
        </div>
        <div className="progress-bar">
          <div className="progress-fill" style={{ width: `${volumePercent}%` }} />
        </div>
      </div>

      <div className="usage-history">
        <div className="history-title">{t("usageHistoryTitle")}</div>
        {history.length > 0 ? (
          [...history]
            .slice(-5)
            .reverse()
            .map((u, i) => (
              <div className="history-item" key={i}>
                <span className="history-date">{u.date}</span>
                <span className="history-usage">{u.amount.toFixed(1)} GB</span>
              </div>
            ))
        ) : (
          <p style={{ textAlign: "center", color: "var(--gray)", padding: "20px 0" }}>
            {t("usageNoHistory")}
          </p>
        )}
      </div>

      <div style={{ marginTop: 20 }}>
        <button className="btn" onClick={onRecord}>
          <i className="fas fa-plus" /> {t("usageRecordBtn")}
        </button>
        <p className="tagline" style={{ marginTop: 10 }}>
          {t("usageRecordDesc")}
        </p>
      </div>
    </ModalShell>
  );
}

/* ---------------- Amount Modal (add data / add days) ---------------- */
function AmountModal({
  title,
  label,
  desc,
  icon,
  confirmLabel,
  cancelLabel,
  initial,
  onClose,
  onConfirm,
}: {
  title: string;
  label: string;
  desc: string;
  icon: string;
  confirmLabel: string;
  cancelLabel: string;
  initial: number;
  onClose: () => void;
  onConfirm: (value: number) => void;
}) {
  const [value, setValue] = useState(String(initial));
  return (
    <ModalShell
      title={title}
      icon={icon}
      onClose={onClose}
      footer={
        <>
          <button className="btn" onClick={onClose}>
            {cancelLabel}
          </button>
          <button
            className="btn btn-primary"
            onClick={() => {
              const n = parseInt(value, 10);
              if (!isNaN(n) && n > 0) onConfirm(n);
            }}
          >
            {confirmLabel}
          </button>
        </>
      }
    >
      <div className="form-group">
        <label>{label}</label>
        <div className="fancy-input">
          <i className={`fas ${icon}`} />
          <input
            type="number"
            min={1}
            value={value}
            onChange={(e) => setValue(e.target.value)}
          />
        </div>
      </div>
      <p className="tagline">{desc}</p>
    </ModalShell>
  );
}

/* ---------------- Sub Link Modal ---------------- */
function SubLinkModal({
  t,
  link,
  onClose,
}: {
  t: (k: string) => string;
  link: string;
  onClose: () => void;
}) {
  const ref = useRef<HTMLInputElement>(null);
  return (
    <ModalShell
      title={t("subLinkTitle")}
      icon="fa-link"
      onClose={onClose}
      footer={
        <>
          <button className="btn" onClick={onClose}>
            {t("closeBtn")}
          </button>
          <button
            className="btn btn-primary"
            onClick={() => {
              ref.current?.focus();
              ref.current?.select();
            }}
          >
            {t("selectAllBtn")}
          </button>
        </>
      }
    >
      <p className="tagline" style={{ marginBottom: 15 }}>
        {t("subLinkCopiedDesc")}
      </p>
      <div className="fancy-input">
        <i className="fas fa-link" />
        <input ref={ref} type="text" readOnly value={link} />
      </div>
    </ModalShell>
  );
}

/* ---------------- Users Modal (admin) ---------------- */
function UsersModal({
  t,
  onClose,
  showToast,
  refreshMe,
}: {
  t: (k: string) => string;
  onClose: () => void;
  showToast: (title: string, message: string, type?: ToastType) => void;
  refreshMe: () => Promise<void>;
}) {
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [validity, setValidity] = useState("10");
  const [note, setNote] = useState("");
  const [loading, setLoading] = useState(false);

  const load = useCallback(async () => {
    const res = await fetch("/api/admin/users");
    if (res.ok) {
      const d = await res.json();
      setUsers(d.users || []);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const createUser = async () => {
    if (!username.trim() || !password) {
      showToast(t("toastErrorTitle"), t("toastNeedUserFields"), "danger");
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("/api/admin/users", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: username.trim(),
          password,
          validityDays: Number(validity),
          note,
        }),
      });
      const d = await res.json().catch(() => ({}));
      if (d.ok) {
        setUsername("");
        setPassword("");
        setNote("");
        await load();
        showToast(
          t("toastUserCreatedTitle"),
          t("toastUserCreatedMsg").replace("{name}", d.user.username),
          "success"
        );
      } else if (d.error === "USERNAME_TAKEN") {
        showToast(t("toastErrorTitle"), t("toastUserTakenMsg"), "danger");
      } else {
        showToast(t("toastErrorTitle"), t("toastNeedUserFields"), "danger");
      }
    } finally {
      setLoading(false);
    }
  };

  const patchUser = async (id: number, body: Record<string, unknown>) => {
    await fetch(`/api/admin/users/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    await load();
    await refreshMe();
    showToast(t("toastUserUpdatedTitle"), t("toastUserUpdatedTitle"), "success");
  };

  const deleteUser = async (u: AdminUser) => {
    if (!window.confirm(t("confirmDeleteUser"))) return;
    await fetch(`/api/admin/users/${u.id}`, { method: "DELETE" });
    await load();
    showToast(t("toastUserDeletedTitle"), t("toastUserDeletedTitle"), "success");
  };

  return (
    <ModalShell
      title={t("usersTitle")}
      icon="fa-users-cog"
      onClose={onClose}
      wide
      footer={
        <button className="btn" onClick={onClose}>
          {t("closeBtn")}
        </button>
      }
    >
      <p className="tagline">{t("usersDesc")}</p>

      <h3 style={{ color: "var(--primary)", margin: "10px 0 15px" }}>
        <i className="fas fa-user-plus" /> {t("newUserTitle")}
      </h3>
      <div className="form-row">
        <div className="form-group">
          <label>{t("userUsernameLabel")}</label>
          <input
            className="plain-input"
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
        </div>
        <div className="form-group">
          <label>{t("userPasswordLabel")}</label>
          <input
            className="plain-input"
            type="text"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
      </div>
      <div className="form-row">
        <div className="form-group">
          <label>{t("userValidityLabel")}</label>
          <input
            className="plain-input"
            type="number"
            min={1}
            value={validity}
            onChange={(e) => setValidity(e.target.value)}
          />
        </div>
        <div className="form-group">
          <label>{t("userNoteLabel")}</label>
          <input
            className="plain-input"
            type="text"
            value={note}
            onChange={(e) => setNote(e.target.value)}
          />
        </div>
      </div>
      <button className="btn btn-primary" onClick={createUser} disabled={loading}>
        <i className="fas fa-plus" /> {t("createUserBtn")}
      </button>

      <h3 style={{ color: "var(--primary)", margin: "25px 0 10px" }}>
        <i className="fas fa-users" /> {users.filter((u) => u.role === "user").length}
      </h3>
      <div className="table-scroll">
        <table className="users-table">
          <thead>
            <tr>
              <th>{t("colUsername")}</th>
              <th>{t("colStatus")}</th>
              <th>{t("colDaysLeft")}</th>
              <th>{t("colConfigs")}</th>
              <th>{t("colExpires")}</th>
              <th>{t("colActions")}</th>
            </tr>
          </thead>
          <tbody>
            {users.filter((u) => u.role === "user").length === 0 ? (
              <tr>
                <td colSpan={6} style={{ textAlign: "center", color: "var(--gray)" }}>
                  {t("noUsers")}
                </td>
              </tr>
            ) : (
              users
                .filter((u) => u.role === "user")
                .map((u) => (
                  <tr key={u.id}>
                    <td>
                      {u.username}
                      {u.note ? (
                        <div style={{ color: "var(--gray)", fontSize: "0.75rem" }}>
                          {u.note}
                        </div>
                      ) : null}
                    </td>
                    <td>
                      <span
                        className={`badge ${
                          u.isActive && !u.expired ? "badge-ok" : "badge-off"
                        }`}
                      >
                        {u.isActive && !u.expired
                          ? t("statusActive")
                          : t("statusInactive")}
                      </span>
                    </td>
                    <td>{u.daysLeft}</td>
                    <td>{u.configCount}</td>
                    <td>
                      {u.expiresAt
                        ? new Date(u.expiresAt).toLocaleDateString("en-US")
                        : "-"}
                    </td>
                    <td style={{ whiteSpace: "nowrap" }}>
                      <button
                        className="icon-btn"
                        title={t("tipToggle")}
                        onClick={() => patchUser(u.id, { action: "toggle" })}
                      >
                        <i className="fas fa-power-off" />
                      </button>
                      <button
                        className="icon-btn"
                        title={t("tipAddDays")}
                        onClick={() => {
                          const v = window.prompt(t("promptAddDaysUser"), "30");
                          const n = v ? parseInt(v, 10) : 0;
                          if (n > 0) patchUser(u.id, { action: "addDays", days: n });
                        }}
                      >
                        <i className="fas fa-calendar-plus" />
                      </button>
                      <button
                        className="icon-btn"
                        title={t("tipResetPw")}
                        onClick={() => {
                          const v = window.prompt(t("promptResetPw"));
                          if (v)
                            patchUser(u.id, { action: "resetPassword", password: v });
                        }}
                      >
                        <i className="fas fa-key" />
                      </button>
                      <button
                        className="icon-btn"
                        title={t("tipDelete")}
                        style={{ color: "var(--danger)" }}
                        onClick={() => deleteUser(u)}
                      >
                        <i className="fas fa-trash" />
                      </button>
                    </td>
                  </tr>
                ))
            )}
          </tbody>
        </table>
      </div>
    </ModalShell>
  );
}
