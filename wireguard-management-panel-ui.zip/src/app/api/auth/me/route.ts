import { ensureAdmin, getCurrentUser, isExpired, daysLeft } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  await ensureAdmin();
  const user = await getCurrentUser();
  if (!user) {
    return Response.json({ ok: false, user: null }, { status: 401 });
  }
  if (!user.isActive || isExpired(user)) {
    return Response.json({ ok: false, user: null }, { status: 403 });
  }
  return Response.json({
    ok: true,
    user: {
      id: user.id,
      username: user.username,
      role: user.role,
      daysLeft: daysLeft(user),
      expiresAt: user.expiresAt,
    },
  });
}
