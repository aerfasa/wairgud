import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import {
  ensureAdmin,
  verifyPassword,
  createSession,
  isExpired,
  daysLeft,
} from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  await ensureAdmin();

  const body = await req.json().catch(() => ({}));
  const username = String(body.username || "").trim();
  const password = String(body.password || "");

  if (!username || !password) {
    return Response.json(
      { ok: false, error: "USERNAME_PASSWORD_REQUIRED" },
      { status: 400 }
    );
  }

  const rows = await db
    .select()
    .from(users)
    .where(eq(users.username, username))
    .limit(1);
  const user = rows[0];

  if (!user || !(await verifyPassword(password, user.passwordHash))) {
    return Response.json({ ok: false, error: "INVALID_CREDENTIALS" }, { status: 401 });
  }

  if (!user.isActive) {
    return Response.json({ ok: false, error: "ACCOUNT_DISABLED" }, { status: 403 });
  }

  if (isExpired(user)) {
    return Response.json({ ok: false, error: "ACCOUNT_EXPIRED" }, { status: 403 });
  }

  await createSession({ uid: user.id, username: user.username, role: user.role });

  return Response.json({
    ok: true,
    user: {
      id: user.id,
      username: user.username,
      role: user.role,
      daysLeft: daysLeft(user),
      expiresAt: user.expiresAt,
    },
  });
}
