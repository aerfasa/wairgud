import { db } from "@/db";
import { sql } from "drizzle-orm";
import { ensureAdmin } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await db.execute(sql`select 1`);
    await ensureAdmin(); // ensures schema + default admin exist
    return Response.json({ ok: true });
  } catch {
    return Response.json({ ok: false }, { status: 500 });
  }
}
