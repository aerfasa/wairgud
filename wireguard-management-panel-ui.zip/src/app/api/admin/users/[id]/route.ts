import { db } from "@/db";
import { users, configs } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getCurrentUser, hashPassword, daysLeft, isExpired } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const admin = await getCurrentUser();
  if (!admin || admin.role !== "admin") {
    return Response.json({ ok: false }, { status: 403 });
  }

  const { id: idStr } = await params;
  const id = parseInt(idStr, 10);
  const rows = await db.select().from(users).where(eq(users.id, id)).limit(1);
  const target = rows[0];
  if (!target) return Response.json({ ok: false }, { status: 404 });
  if (target.role === "admin") {
    return Response.json({ ok: false, error: "CANNOT_MODIFY_ADMIN" }, { status: 400 });
  }

  const body = await req.json().catch(() => ({}));
  const action = String(body.action || "");
  const updates: Partial<typeof users.$inferInsert> = {};

  if (action === "toggle") {
    updates.isActive = !target.isActive;
  } else if (action === "addDays") {
    const days = parseInt(String(body.days || 0), 10);
    if (days > 0) {
      const base =
        target.expiresAt && new Date(target.expiresAt).getTime() > Date.now()
          ? new Date(target.expiresAt)
          : new Date();
      base.setDate(base.getDate() + days);
      updates.expiresAt = base;
      updates.validityDays = target.validityDays + days;
    }
  } else if (action === "resetPassword") {
    const password = String(body.password || "");
    if (!password) {
      return Response.json({ ok: false, error: "PASSWORD_REQUIRED" }, { status: 400 });
    }
    updates.passwordHash = await hashPassword(password);
  } else {
    return Response.json({ ok: false, error: "UNKNOWN_ACTION" }, { status: 400 });
  }

  const result = await db.update(users).set(updates).where(eq(users.id, id)).returning();
  const u = result[0];
  return Response.json({
    ok: true,
    user: {
      id: u.id,
      username: u.username,
      role: u.role,
      validityDays: u.validityDays,
      isActive: u.isActive,
      createdAt: u.createdAt,
      expiresAt: u.expiresAt,
      note: u.note,
      daysLeft: daysLeft(u),
      expired: isExpired(u),
    },
  });
}

export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const admin = await getCurrentUser();
  if (!admin || admin.role !== "admin") {
    return Response.json({ ok: false }, { status: 403 });
  }

  const { id: idStr } = await params;
  const id = parseInt(idStr, 10);
  const rows = await db.select().from(users).where(eq(users.id, id)).limit(1);
  const target = rows[0];
  if (!target) return Response.json({ ok: false }, { status: 404 });
  if (target.role === "admin") {
    return Response.json({ ok: false, error: "CANNOT_DELETE_ADMIN" }, { status: 400 });
  }

  await db.delete(configs).where(eq(configs.ownerId, id));
  await db.delete(users).where(eq(users.id, id));
  return Response.json({ ok: true });
}
