import { db } from "@/db";
import { users, configs } from "@/db/schema";
import { eq, desc, sql } from "drizzle-orm";
import { getCurrentUser, hashPassword, daysLeft, isExpired } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  const admin = await getCurrentUser();
  if (!admin || admin.role !== "admin") {
    return Response.json({ ok: false }, { status: 403 });
  }

  const rows = await db.select().from(users).orderBy(desc(users.id));

  // config counts per user
  const counts = await db
    .select({ ownerId: configs.ownerId, count: sql<number>`count(*)::int` })
    .from(configs)
    .groupBy(configs.ownerId);
  const countMap = new Map(counts.map((c) => [c.ownerId, c.count]));

  const list = rows.map((u) => ({
    id: u.id,
    username: u.username,
    role: u.role,
    validityDays: u.validityDays,
    isActive: u.isActive,
    createdAt: u.createdAt,
    expiresAt: u.expiresAt,
    note: u.note,
    daysLeft: daysLeft(u),
    expired: isExpired(u),
    configCount: countMap.get(u.id) ?? 0,
  }));

  return Response.json({ ok: true, users: list });
}

export async function POST(req: Request) {
  const admin = await getCurrentUser();
  if (!admin || admin.role !== "admin") {
    return Response.json({ ok: false }, { status: 403 });
  }

  const body = await req.json().catch(() => ({}));
  const username = String(body.username || "").trim();
  const password = String(body.password || "");
  const days = parseInt(String(body.validityDays ?? "10"), 10) || 10;
  const note = String(body.note || "");

  if (!username || !password) {
    return Response.json({ ok: false, error: "USERNAME_PASSWORD_REQUIRED" }, { status: 400 });
  }

  const existing = await db
    .select()
    .from(users)
    .where(eq(users.username, username))
    .limit(1);
  if (existing.length > 0) {
    return Response.json({ ok: false, error: "USERNAME_TAKEN" }, { status: 409 });
  }

  const now = new Date();
  const expires = new Date();
  expires.setDate(expires.getDate() + days);

  const inserted = await db
    .insert(users)
    .values({
      username,
      passwordHash: await hashPassword(password),
      role: "user",
      validityDays: days,
      isActive: true,
      createdAt: now,
      expiresAt: expires,
      note,
    })
    .returning();

  const u = inserted[0];
  return Response.json({
    ok: true,
    user: {
      id: u.id,
      username: u.username,
      role: u.role,
      validityDays: u.validityDays,
      isActive: u.isActive,
      createdAt: u.createdAt,
      expiresAt: u.expiresAt,
      note: u.note,
      daysLeft: daysLeft(u),
      expired: false,
      configCount: 0,
    },
  });
}
