import { db } from "@/db";
import { configs } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";
import {
  WG_SERVERS,
  CONFIG_TEMPLATES,
  parseConfigText,
  makeSubId,
  type CountryCode,
} from "@/lib/wireguard";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return Response.json({ ok: false }, { status: 401 });

  const rows = await db
    .select()
    .from(configs)
    .where(eq(configs.ownerId, user.id))
    .orderBy(desc(configs.id));

  return Response.json({ ok: true, configs: rows });
}

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return Response.json({ ok: false }, { status: 401 });

  const body = await req.json().catch(() => ({}));
  const name = String(body.name || "").trim();
  const country = (String(body.country || "UAE") as CountryCode) in WG_SERVERS
    ? (body.country as CountryCode)
    : "UAE";
  const volumeRaw = String(body.volume ?? "100");
  const dailyRaw = String(body.dailyLimit ?? "10");
  const days = parseInt(String(body.days ?? "30"), 10) || 30;

  if (!name) {
    return Response.json({ ok: false, error: "NAME_REQUIRED" }, { status: 400 });
  }

  const server = WG_SERVERS[country];
  const configText = CONFIG_TEMPLATES[country];
  const { privateKey, publicKey, address } = parseConfigText(configText);

  const now = new Date();
  const expire = new Date();
  expire.setDate(expire.getDate() + days);

  const inserted = await db
    .insert(configs)
    .values({
      ownerId: user.id,
      subId: makeSubId(),
      name,
      country,
      volume: volumeRaw === "unlimited" ? -1 : parseInt(volumeRaw, 10),
      volumeUsed: 0,
      dailyLimit: dailyRaw === "unlimited" ? -1 : parseInt(dailyRaw, 10),
      dailyUsed: 0,
      days,
      daysUsed: 0,
      isActive: true,
      configText,
      address,
      privateKey,
      publicKey,
      usageHistory: [],
      createdAt: now,
      expiresAt: expire,
    })
    .returning();

  return Response.json({ ok: true, config: inserted[0], server });
}
