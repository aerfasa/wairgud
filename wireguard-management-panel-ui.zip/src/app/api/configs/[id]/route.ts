import { db } from "@/db";
import { configs } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

interface UsageEntry {
  date: string;
  amount: number;
}

async function loadOwned(id: number, userId: number) {
  const rows = await db
    .select()
    .from(configs)
    .where(and(eq(configs.id, id), eq(configs.ownerId, userId)))
    .limit(1);
  return rows[0] ?? null;
}

export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await getCurrentUser();
  if (!user) return Response.json({ ok: false }, { status: 401 });

  const { id: idStr } = await params;
  const id = parseInt(idStr, 10);
  const config = await loadOwned(id, user.id);
  if (!config) return Response.json({ ok: false }, { status: 404 });

  const body = await req.json().catch(() => ({}));
  const action = String(body.action || "");

  const updates: Partial<typeof configs.$inferInsert> = {};

  if (action === "toggle") {
    updates.isActive = !config.isActive;
  } else if (action === "addData") {
    const amount = parseInt(String(body.amount || 0), 10);
    if (amount > 0 && config.volume !== -1) {
      updates.volume = config.volume + amount;
    }
  } else if (action === "addDays") {
    const days = parseInt(String(body.days || 0), 10);
    if (days > 0) {
      const expire = new Date(config.expiresAt);
      expire.setDate(expire.getDate() + days);
      updates.expiresAt = expire;
      updates.days = config.days + days;
    }
  } else if (action === "recordUsage") {
    if (!config.isActive) {
      return Response.json({ ok: false, error: "INACTIVE" }, { status: 400 });
    }
    const usageToAdd = 0.4; // 400MB
    let expiresAt = new Date(config.expiresAt);
    let daysUsed = config.daysUsed;
    let limitExceeded = false;
    if (config.dailyLimit !== -1 && config.dailyUsed + usageToAdd > config.dailyLimit) {
      expiresAt.setDate(expiresAt.getDate() - 1);
      daysUsed += 1;
      limitExceeded = true;
    }
    const history = (config.usageHistory as UsageEntry[]) || [];
    history.push({
      date: new Date().toLocaleDateString("en-US"),
      amount: usageToAdd,
    });
    updates.dailyUsed = config.dailyUsed + usageToAdd;
    updates.volumeUsed = config.volumeUsed + usageToAdd;
    updates.daysUsed = Math.min(daysUsed + 1, config.days);
    updates.expiresAt = expiresAt;
    updates.usageHistory = history;
    const result = await db
      .update(configs)
      .set(updates)
      .where(eq(configs.id, id))
      .returning();
    return Response.json({ ok: true, config: result[0], limitExceeded });
  } else {
    return Response.json({ ok: false, error: "UNKNOWN_ACTION" }, { status: 400 });
  }

  const result = await db
    .update(configs)
    .set(updates)
    .where(eq(configs.id, id))
    .returning();
  return Response.json({ ok: true, config: result[0] });
}

export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await getCurrentUser();
  if (!user) return Response.json({ ok: false }, { status: 401 });

  const { id: idStr } = await params;
  const id = parseInt(idStr, 10);
  const config = await loadOwned(id, user.id);
  if (!config) return Response.json({ ok: false }, { status: 404 });

  await db.delete(configs).where(eq(configs.id, id));
  return Response.json({ ok: true });
}
