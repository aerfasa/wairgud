import { db } from "@/db";
import { configs } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ subId: string }> }
) {
  const { subId } = await params;
  const rows = await db
    .select()
    .from(configs)
    .where(eq(configs.subId, subId))
    .limit(1);
  const config = rows[0];

  if (!config) {
    return new Response("# Configuration not found", {
      status: 404,
      headers: { "Content-Type": "text/plain; charset=utf-8" },
    });
  }

  if (!config.isActive) {
    return new Response("# Configuration is disabled", {
      status: 403,
      headers: { "Content-Type": "text/plain; charset=utf-8" },
    });
  }

  if (new Date(config.expiresAt).getTime() < Date.now()) {
    return new Response("# Configuration has expired", {
      status: 403,
      headers: { "Content-Type": "text/plain; charset=utf-8" },
    });
  }

  const safeName = config.name.replace(/[^a-zA-Z0-9_-]/g, "_");
  return new Response(config.configText, {
    status: 200,
    headers: {
      "Content-Type": "text/plain; charset=utf-8",
      "Content-Disposition": `inline; filename="${safeName}.conf"`,
      "Cache-Control": "no-store",
    },
  });
}
