import { db } from "@/db";
import { sql } from "drizzle-orm";

let schemaReady = false;

// Creates tables if they do not exist. This makes the app deploy cleanly on
// Railway (or any fresh Postgres) without a separate migration step.
export async function ensureSchema() {
  if (schemaReady) return;

  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS users (
      id SERIAL PRIMARY KEY,
      username TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'user',
      validity_days INTEGER NOT NULL DEFAULT 30,
      is_active BOOLEAN NOT NULL DEFAULT true,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
      expires_at TIMESTAMPTZ,
      note TEXT DEFAULT ''
    );
  `);

  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS configs (
      id SERIAL PRIMARY KEY,
      owner_id INTEGER NOT NULL,
      sub_id TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      country TEXT NOT NULL,
      volume INTEGER NOT NULL DEFAULT 100,
      volume_used DOUBLE PRECISION NOT NULL DEFAULT 0,
      daily_limit INTEGER NOT NULL DEFAULT 10,
      daily_used DOUBLE PRECISION NOT NULL DEFAULT 0,
      days INTEGER NOT NULL DEFAULT 30,
      days_used INTEGER NOT NULL DEFAULT 0,
      is_active BOOLEAN NOT NULL DEFAULT true,
      config_text TEXT NOT NULL DEFAULT '',
      address TEXT NOT NULL DEFAULT '',
      private_key TEXT NOT NULL DEFAULT '',
      public_key TEXT NOT NULL DEFAULT '',
      usage_history JSONB NOT NULL DEFAULT '[]'::jsonb,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
      expires_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );
  `);

  schemaReady = true;
}
