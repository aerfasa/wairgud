export interface UsageEntry {
  date: string;
  amount: number;
}

export interface ClientConfig {
  id: number;
  ownerId: number;
  subId: string;
  name: string;
  country: "UAE" | "TR" | "IR";
  volume: number;
  volumeUsed: number;
  dailyLimit: number;
  dailyUsed: number;
  days: number;
  daysUsed: number;
  isActive: boolean;
  configText: string;
  address: string;
  privateKey: string;
  publicKey: string;
  usageHistory: UsageEntry[];
  createdAt: string;
  expiresAt: string;
}

export interface SessionUser {
  id: number;
  username: string;
  role: string;
  daysLeft: number;
  expiresAt: string | null;
}

export interface AdminUser {
  id: number;
  username: string;
  role: string;
  validityDays: number;
  isActive: boolean;
  createdAt: string;
  expiresAt: string | null;
  note: string | null;
  daysLeft: number;
  expired: boolean;
  configCount: number;
}
