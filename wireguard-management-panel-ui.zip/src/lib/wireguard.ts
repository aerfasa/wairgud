export type CountryCode = "UAE" | "TR" | "IR";

export interface WgServer {
  ip: string;
  port: number;
  pubkey: string;
  country: string;
  city: string;
}

export const WG_SERVERS: Record<CountryCode, WgServer> = {
  UAE: {
    ip: "0.0.0.0",
    port: 51820,
    pubkey: "3ArEYLg6wR6NYXrg4RTlI4kQmi5iX0z1ERpfKyxSxhk=",
    country: "United Arab Emirates",
    city: "Dubai",
  },
  TR: {
    ip: "0.0.0.0",
    port: 51820,
    pubkey: "8H3ovcm3xmFxfhmq5jV7aiza4itoynGgOu1tpL7jJEg=",
    country: "Turkey",
    city: "Istanbul",
  },
  IR: {
    ip: "0.0.0.0",
    port: 51820,
    pubkey: "aFP5M1M2VUEByYqLt29xyUCmNT2vYXsVGiUG+DSl2Uo=",
    country: "Iran",
    city: "Tehran",
  },
};

export const CONFIG_TEMPLATES: Record<CountryCode, string> = {
  UAE: `[Interface]
PrivateKey = aDi30cQATlyFXRlOmLzjK68vQxBe7kDYPisjB8Jg51A=
Address = 10.109.77.164/32
DNS = 1.1.1.1, 1.181.121.10
# Name: B11
# Region: 🇦🇪امارات
# VIP: Active

[Peer]
PublicKey = 3ArEYLg6wR6NYXrg4RTlI4kQmi5iX0z1ERpfKyxSxhk=
AllowedIPs = ::/0
Endpoint = 0.0.0.0:51820
PersistentKeepalive = 25`,
  TR: `[Interface]
PrivateKey = iKhR4GJ5wBstKxjkwUDHkMVUoMUL8lxTmql0iW2JTUE=
Address = 10.49.101.173/32
DNS = 1.1.1.1, 1.180.197.251
# Name: B12
# Region: 🇹🇷ترکیه
# VIP: Active

[Peer]
PublicKey = 8H3ovcm3xmFxfhmq5jV7aiza4itoynGgOu1tpL7jJEg=
AllowedIPs = ::/0
Endpoint = 0.0.0.0:51820
PersistentKeepalive = 25`,
  IR: `[Interface]
PrivateKey = kNvr1/n8GbdzCdQxqlBeWQUur2XP5wbB0fjmHnwFZUQ=
Address = 10.39.89.26/32
DNS = 1.1.1.1, 1.182.102.115
# Name: B13
# Region: 🇮🇷ایران
# VIP: Active

[Peer]
PublicKey = aFP5M1M2VUEByYqLt29xyUCmNT2vYXsVGiUG+DSl2Uo=
AllowedIPs = ::/0
Endpoint = 0.0.0.0:51820
PersistentKeepalive = 25`,
};

export function parseConfigText(text: string) {
  const priv = text.match(/PrivateKey\s*=\s*(\S+)/);
  const pub = text.match(/PublicKey\s*=\s*(\S+)/);
  const addr = text.match(/Address\s*=\s*(\S+)/);
  return {
    privateKey: priv ? priv[1] : "",
    publicKey: pub ? pub[1] : "",
    address: addr ? addr[1] : "",
  };
}

export function makeSubId() {
  return (
    "sub_" +
    Math.random().toString(36).substring(2, 10) +
    Math.random().toString(36).substring(2, 10)
  );
}
