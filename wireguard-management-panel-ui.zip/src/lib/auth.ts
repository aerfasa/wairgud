import { cookies } from "next/headers";
import { SignJWT, jwtVerify } from "jose";
import bcrypt from "bcryptjs";
import { db } from "@/db";
import { users, type User } from "@/db/schema";
import { eq } from "drizzle-orm";
import { ensureSchema } from "@/lib/init";

const COOKIE_NAME = "pug62_session";
const SECRET = new TextEncoder().encode(
  process.env.SESSION_SECRET || "pug62-super-secret-change-me-in-railway-env"
);

// Default admin credentials (can be overridden by env vars on Railway).
export const ADMIN_USERNAME = process.env.ADMIN_USERNAME || "arian";
export const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "arian@11USER";

export interface SessionPayload {
  uid: number;
  username: string;
  role: string;
}

export async function hashPassword(plain: string) {
  return bcrypt.hash(plain, 10);
}

export async function verifyPassword(plain: string, hash: string) {
  return bcrypt.compare(plain, hash);
}

export async function createSession(payload: SessionPayload) {
  const token = await new SignJWT({ ...payload })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("7d")
    .sign(SECRET);

  const store = await cookies();
  store.set(COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 60 * 60 * 24 * 7,
  });
}

export async function destroySession() {
  const store = await cookies();
  store.delete(COOKIE_NAME);
}

export async function getSession(): Promise<SessionPayload | null> {
  const store = await cookies();
  const token = store.get(COOKIE_NAME)?.value;
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, SECRET);
    return {
      uid: payload.uid as number,
      username: payload.username as string,
      role: payload.role as string,
    };
  } catch {
    return null;
  }
}

// Returns the fresh DB record for the current session user (or null).
export async function getCurrentUser(): Promise<User | null> {
  const session = await getSession();
  if (!session) return null;
  const rows = await db.select().from(users).where(eq(users.id, session.uid)).limit(1);
  return rows[0] ?? null;
}

export function isExpired(user: User): boolean {
  if (user.role === "admin") return false;
  if (!user.expiresAt) return false;
  return new Date(user.expiresAt).getTime() < Date.now();
}

export function daysLeft(user: User): number {
  if (user.role === "admin") return -1; // unlimited
  if (!user.expiresAt) return 0;
  const ms = new Date(user.expiresAt).getTime() - Date.now();
  return Math.max(0, Math.ceil(ms / (1000 * 60 * 60 * 24)));
}

// Ensures the default admin account exists. Runs lazily on demand.
let adminEnsured = false;
export async function ensureAdmin() {
  if (adminEnsured) return;
  await ensureSchema();
  const existing = await db
    .select()
    .from(users)
    .where(eq(users.username, ADMIN_USERNAME))
    .limit(1);
  if (existing.length === 0) {
    await db.insert(users).values({
      username: ADMIN_USERNAME,
      passwordHash: await hashPassword(ADMIN_PASSWORD),
      role: "admin",
      validityDays: 0,
      isActive: true,
      expiresAt: null,
      note: "Default administrator",
    });
  }
  adminEnsured = true;
}
