import {
  pgTable,
  serial,
  text,
  integer,
  boolean,
  timestamp,
  doublePrecision,
  jsonb,
} from "drizzle-orm/pg-core";

// Application user accounts.
// - role "admin" : full access, can manage users (never expires)
// - role "user"  : normal panel user, created by the admin with a validity period
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  role: text("role").notNull().default("user"), // "admin" | "user"
  validityDays: integer("validity_days").notNull().default(30),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  expiresAt: timestamp("expires_at", { withTimezone: true }),
  note: text("note").default(""),
});

// WireGuard configurations, each owned by a user.
export const configs = pgTable("configs", {
  id: serial("id").primaryKey(),
  ownerId: integer("owner_id").notNull(),
  subId: text("sub_id").notNull().unique(),
  name: text("name").notNull(),
  country: text("country").notNull(), // UAE | TR | IR
  volume: integer("volume").notNull().default(100), // GB, -1 = unlimited
  volumeUsed: doublePrecision("volume_used").notNull().default(0),
  dailyLimit: integer("daily_limit").notNull().default(10), // GB, -1 = unlimited
  dailyUsed: doublePrecision("daily_used").notNull().default(0),
  days: integer("days").notNull().default(30),
  daysUsed: integer("days_used").notNull().default(0),
  isActive: boolean("is_active").notNull().default(true),
  configText: text("config_text").notNull().default(""),
  address: text("address").notNull().default(""),
  privateKey: text("private_key").notNull().default(""),
  publicKey: text("public_key").notNull().default(""),
  usageHistory: jsonb("usage_history").notNull().default([]),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull().defaultNow(),
});

export type User = typeof users.$inferSelect;
export type NewUser = typeof users.$inferInsert;
export type Config = typeof configs.$inferSelect;
export type NewConfig = typeof configs.$inferInsert;
